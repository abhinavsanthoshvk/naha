# NAHDA – Gold & Diamonds (Vercel static deployment)

This project is a static HTML website. It does not require Python, Flask, Django, `main.py`, or a Python runtime.

## Project structure

    index.html
    vercel.json
    README.md

## Deploy with GitHub and Vercel

1. Upload these files to the root of your GitHub repository.
2. In Vercel, open the project and go to Settings → Build and Deployment.
3. Set the Framework Preset to **Other**.
4. Set the Root Directory to the folder containing `index.html` (usually `.` / repository root).
5. Remove any custom Build Command or Output Directory override that expects a Python app or `main.py`.
6. Redeploy from the Deployments tab.

For this static site, Vercel can serve `index.html` directly. Do not add a Python entrypoint just to suppress the error.

If the same error remains, check whether Vercel is deploying a different branch or subdirectory, or whether an old custom build configuration is still active.
